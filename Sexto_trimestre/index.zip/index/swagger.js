const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.3',
    info: {
      title: 'Proyecto Reserve Shoot - OpenAPI 3.0',
      description: ` OpenAPI 3.0 - Este es un servidor de un proyecto llamado Reserve Shoot que consiste en reservas para actividades recreativas puestas por empresas que se dedican a ello, y estas reservas son hechas por clientes interesados en hacer una reserva con alguna empresa de su interés.`, 
    },
    servers: [
      {
        url: 'http://localhost:9300/',
      },
    ],
    tags: [
      {
        name: 'Cliente',
        description: 'Las personas interezadas en realizar una reserva.',
        externalDocs: {
          description: 'Crear una cuenta para usar el aplicativo.',
          url: 'http://localhost:9300/',
        },
      },
      {
        name: 'Empresa',
        description: 'Las empresas podran mostrar lo que ofrecen para que el cliente reserve con ellas',
        externalDocs: {
          description: 'Tener una cuenta para hacerse notar en el aplicativo',
          url: 'http://localhost:9300/',
        },
      },
      {
        name: 'Administrador',
        description: 'Los administradores podran ver la informacion almacenada',
        externalDocs: {
          description: 'Poder ver y manejar la informacion almacenada',
          url: 'http://localhost:9300/',
        }
      },
      {
        name: 'Reservas',
        description: 'Como es el sistema',
        externalDocs: {
          description: 'Lo que hace el sistema para el uso del usuario',
          url: 'http://localhost:9300/',
        }
      },
    ],
  },
  apis: ['./index.js'],
};

const specs = swaggerJsdoc(options);

module.exports = { specs, swaggerUi };
