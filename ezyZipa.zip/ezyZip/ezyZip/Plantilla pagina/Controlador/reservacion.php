<?php
$con = mysqli_connect('127.0.0.1', 'root', '', 'sena_project');
if (!$con) {
die("<center><p>La conexión a la base de datos ha fallado: </p></center>" . mysqli_connect_error());
};

$ocasion = $_POST['oca'];
$fecha = $_POST['Fec_reservacion'];
$hora = $_POST['Hor_reservacion'];
$lugar = $_POST['Lug_reserva'];
$nom_empresa=$_POST['Nombre_empresa'];
$nom_usuario=$_POST['Nombre_usuario'];
$plata=$_POST['Valor_reserva'];
$empleado=$_POST['emp'];

$empresa="SELECT Nit_Empresa From empresa WHERE Nombre_empresa='$nom_empresa';";
$rempresa=$con->query($empresa);
if ($rempresa->num_rows>0){
    $row = $rempresa->fetch_assoc();
    $nit = $row["Nit_Empresa"];
}
$usuario="SELECT id_Cliente FROM cliente WHERE Nombre_cliente='$nom_usuario';";
$rusuario=$con->query($usuario);
if ($rusuario->num_rows>0){
$row=$rusuario->fetch_assoc();
$id=$row["id_Cliente"];
}
$insertar = "INSERT INTO reservacion (Servicio_idServicio,Fecha_reservacion,Hora_reservacion,Lugar_reservacion_idLugar_reservacion,Empresa_Nit_Empresa,Cliente_id_Cliente,Valor,Empleados_id_empleado) VALUES('$ocasion','$fecha','$hora','$lugar','$nit','$id','$plata','$empleado')";
// echo $ocasion."-".$fecha."-".$hora."-".$lugar."-".$nit."-".$id."-".$plata."-".$empleado;
$query = mysqli_query($con, $insertar);
if($query){
echo "<script>alert('La reserva ha sido éxitosa.')</script>";    
header("location:../paginaprincipalplantilla.html");
exit();
}else{
echo "incorrecto";
 } 
?>