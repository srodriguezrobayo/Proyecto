<?php
    $conn=mysqli_connect('localhost','root','','sena_project');
    session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: Login.html'); // Redirige a la página de inicio de sesión
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="CSS/Estilo.CSS">
    <title>Perfil usuario</title>
    <style>
        table, thead, th{
            border: 1px solid  dimgrey;
            border-collapse: collapse;
            padding: 10px;
            flex-flow: row wrap ;
            justify-content: flex-end;
            background-color: grey;
            color: #FF0000;
            font-weight: bold;
        }
        table, tbody, tr, td{
            border: 1px solid dimgrey;
            padding: 10px;
            flex-flow: row wrap ;
            justify-content: flex-end;
            width: 16%;
            background-color: gray;
            color: black;
            font-weight: bold;
        }
        table, tfoot, tr, td{
            border: 1px solid  dimgrey;
            padding: 10px;
            flex-flow: row wrap ;
            justify-content: flex-end;
            width: 16%;
            background-color: gray;
            color: black;
            font-weight: bold;
        }
        .correo{
            width: 16px;
            height: 16px;
            display: inline-block;
            background-size: cover;
            background-image: url("https://cdn-icons-png.flaticon.com/512/281/281769.png");
        }
        .telefono{
            width: 16px;
            height: 16px;
            display: inline-block;
            background-size: cover;
            background-image: url("https://cdn-icons-png.flaticon.com/512/724/724664.png");
        }
    </style>
</head>
<body>
    <header>
        <center><img src="img/icono.jpg" alt="Sistema de reservas para actividades recreativas" id="Icono"></center>
        <a href="Controlador/Adios.php" id="adios">Cerrar sesion</a> 
        <br>
        <hr>
        <div id="menu">
            <ul>
              <li><a href="paginaprincipalplantilla.html">Inicio</a></li>
              <li><a href="perfilcliente.html">Perfil</a></li>
            </ul>
        </div>
        <hr> 
    </header>
    <center><h1>Perfil</h1></center>
    <hr>
    <h2 align="left"> Nombre del cliente</h2>
    <i class="correo"></i>
    <a href="mailto:Correocliente@gmail.com"> Correocliente@gmail.com</a>
    <i class="telefono"></i>
     1-1111-1111
    <div align="right">
        <img src="https://img2.freepng.es/20180331/eow/kisspng-computer-icons-user-clip-art-user-5abf13db298934.2968784715224718991702.jpg" alt="user image" width="100"/>
    </div>
    <h4>Descripcion</h4>
    <p>Descripcion del usuario</p>
    <br>
    <hr>
    <br>
    <div align="center">
        <table >
            <thead>
                <th colspan="8">Tus reservas hechas</th>
            </thead>
            <tbody align="center">
                <tr>
                    <td>Id Reservacion</td>
                    <td>Id Servicio</td>
                    <td>Fecha Reservacion</td>
                    <td>Hora Reservacion</td>
                    <td>Lugar Reservacion</td>
                    <td>Nit Empresa</td>
                    <td>Valor</td>
                    <td>Id Empleado</td>
                </tr>

                <?php
                    $sql="SELECT * from reservacion";
                    $result=mysqli_query($conn,$sql);

                    while($mostrar=mysqli_fetch_array($result)){
                ?>

                <tr>
                    <td><?php echo $mostrar['Id_Reservacion'] ?></td>
                    <td><?php echo $mostrar['Servicio_idServicio'] ?></td>
                    <td><?php echo $mostrar['Fecha_reservacion'] ?></td>
                    <td><?php echo $mostrar['Hora_reservacion'] ?></td>
                    <td><?php echo $mostrar['Lugar_reservacion_idLugar_reservacion'] ?></td>
                    <td><?php echo $mostrar['Empresa_Nit_Empresa'] ?></td>
                    <td><?php echo $mostrar['Valor'] ?></td>
                    <td><?php echo $mostrar['Empleados_id_empleado'] ?></td>
                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
    <footer>
        <p id="mio">Derechos resevados</p>
        <p id="mio">© Copyrigth 2022</p>
      </footer>

</body>
</html>
